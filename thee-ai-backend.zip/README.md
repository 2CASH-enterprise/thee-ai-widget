# Assistant IA Immobilier — MVP

## Démarrage rapide

```bash
# 1. Cloner et installer
git clone <repo>
cd immo-assistant
pip install -r requirements.txt

# 2. Configurer l'environnement
cp .env.example .env
# → éditer .env avec vos clés API

# 3. Lancer
uvicorn app.main:app --reload
```

API disponible sur `http://localhost:8000`  
Docs interactives : `http://localhost:8000/docs`

## Intégrer le widget sur un site

```html
<script
  src="https://votre-cdn.com/chat-widget.js"
  data-agency="agence-dupont"
  data-name="Agence Dupont Immobilier">
</script>
```

## Routes API

| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/chat` | Envoyer un message |
| POST | `/leads/update` | Mettre à jour un lead |
| GET | `/leads?agency_id=xxx` | Lister les leads |
| GET | `/health` | Statut de l'API |

## Déploiement (Render.com)

1. Pousser sur GitHub
2. Créer un "Web Service" sur render.com
3. Start command : `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Ajouter les variables d'environnement

## Stack

- **Backend** : FastAPI + SQLAlchemy async
- **IA** : OpenAI gpt-4o-mini
- **DB** : PostgreSQL (Supabase)
- **Email** : SendGrid
- **RDV** : Calendly
- **Widget** : Vanilla JS (aucune dépendance)
