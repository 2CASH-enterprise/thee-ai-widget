/**
 * Assistant IA Immobilier — Widget embarquable
 * Usage : <script src="chat-widget.js" data-agency="mon-agence" data-name="Mon Agence"></script>
 */
(function () {
  const API_URL = "https://votre-api.onrender.com"; // ← changer en prod
  const agencyId = document.currentScript?.dataset?.agency || "default";
  const agencyName = document.currentScript?.dataset?.name || "Notre Agence";
  const sessionId = "session_" + Math.random().toString(36).slice(2);

  // ── Styles ─────────────────────────────────────────────────────────────────
  const css = `
    #immo-chat-btn {
      position: fixed; bottom: 24px; right: 24px; z-index: 9999;
      width: 60px; height: 60px; border-radius: 50%;
      background: #1a56db; color: #fff; border: none;
      font-size: 28px; cursor: pointer; box-shadow: 0 4px 16px rgba(0,0,0,.25);
      display: flex; align-items: center; justify-content: center;
      transition: transform .2s;
    }
    #immo-chat-btn:hover { transform: scale(1.08); }
    #immo-chat-box {
      position: fixed; bottom: 96px; right: 24px; z-index: 9999;
      width: 360px; max-height: 520px;
      background: #fff; border-radius: 16px;
      box-shadow: 0 8px 32px rgba(0,0,0,.18);
      display: flex; flex-direction: column; overflow: hidden;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      transition: opacity .2s, transform .2s;
    }
    #immo-chat-box.hidden { opacity: 0; pointer-events: none; transform: translateY(12px); }
    #immo-chat-header {
      background: #1a56db; color: #fff; padding: 14px 18px;
      font-weight: 600; font-size: 15px; display: flex; justify-content: space-between;
    }
    #immo-chat-header span { font-size: 12px; font-weight: 400; opacity: .8; }
    #immo-chat-messages {
      flex: 1; overflow-y: auto; padding: 16px; display: flex;
      flex-direction: column; gap: 10px; background: #f8f9fa;
    }
    .immo-msg {
      max-width: 82%; padding: 10px 14px; border-radius: 14px;
      font-size: 14px; line-height: 1.5;
    }
    .immo-msg.user {
      align-self: flex-end; background: #1a56db; color: #fff;
      border-bottom-right-radius: 4px;
    }
    .immo-msg.assistant {
      align-self: flex-start; background: #fff; color: #1a1a2e;
      border: 1px solid #e5e7eb; border-bottom-left-radius: 4px;
    }
    .immo-msg.typing { opacity: .6; font-style: italic; }
    #immo-chat-input-area {
      display: flex; gap: 8px; padding: 12px 14px;
      border-top: 1px solid #e5e7eb; background: #fff;
    }
    #immo-chat-input {
      flex: 1; border: 1px solid #d1d5db; border-radius: 20px;
      padding: 9px 16px; font-size: 14px; outline: none;
      font-family: inherit;
    }
    #immo-chat-input:focus { border-color: #1a56db; }
    #immo-chat-send {
      background: #1a56db; color: #fff; border: none; border-radius: 50%;
      width: 38px; height: 38px; font-size: 18px; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
    }
  `;

  const style = document.createElement("style");
  style.textContent = css;
  document.head.appendChild(style);

  // ── HTML ───────────────────────────────────────────────────────────────────
  const btn = document.createElement("button");
  btn.id = "immo-chat-btn";
  btn.innerHTML = "🏠";
  btn.title = "Parler à notre assistant";

  const box = document.createElement("div");
  box.id = "immo-chat-box";
  box.className = "hidden";
  box.innerHTML = `
    <div id="immo-chat-header">
      ${agencyName}
      <span>Assistant IA • En ligne</span>
    </div>
    <div id="immo-chat-messages"></div>
    <div id="immo-chat-input-area">
      <input id="immo-chat-input" type="text" placeholder="Votre message..." autocomplete="off"/>
      <button id="immo-chat-send">➤</button>
    </div>
  `;

  document.body.appendChild(btn);
  document.body.appendChild(box);

  // ── Logique ────────────────────────────────────────────────────────────────
  const messagesEl = box.querySelector("#immo-chat-messages");
  const input = box.querySelector("#immo-chat-input");
  const sendBtn = box.querySelector("#immo-chat-send");
  let isOpen = false;

  function toggleChat() {
    isOpen = !isOpen;
    box.classList.toggle("hidden", !isOpen);
    if (isOpen && messagesEl.children.length === 0) {
      addMessage("assistant", `Bonjour ! Je suis l'assistant de ${agencyName}. Comment puis-je vous aider aujourd'hui ? 🏠`);
    }
    if (isOpen) input.focus();
  }

  function addMessage(role, text) {
    const el = document.createElement("div");
    el.className = `immo-msg ${role}`;
    el.textContent = text;
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return el;
  }

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    addMessage("user", text);

    const typing = addMessage("assistant", "…");
    typing.classList.add("typing");

    try {
      const res = await fetch(`${API_URL}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: sessionId,
          message: text,
          agency_id: agencyId,
          agency_name: agencyName,
        }),
      });
      const data = await res.json();
      typing.remove();
      addMessage("assistant", data.reply);
    } catch {
      typing.remove();
      addMessage("assistant", "Désolé, une erreur est survenue. Réessayez dans un moment.");
    }
  }

  btn.addEventListener("click", toggleChat);
  sendBtn.addEventListener("click", sendMessage);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendMessage();
  });
})();
