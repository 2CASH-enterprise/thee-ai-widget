from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    openai_api_key: str
    database_url: str
    sendgrid_api_key: str = ""
    from_email: str = "assistant@agence.fr"
    calendly_api_key: str = ""
    calendly_event_url: str = ""
    secret_key: str = "dev-secret"
    environment: str = "development"
    allowed_origins: List[str] = ["http://localhost:3000"]

    class Config:
        env_file = ".env"


settings = Settings()
