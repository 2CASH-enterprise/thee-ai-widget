from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.conversation import Message
from app.models.lead import Lead
from app.core.llm import chat_completion, detect_intent
from app.core.prompts import build_system_prompt, SAMPLE_LISTINGS
from app.config import settings

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    session_id: str
    message: str
    agency_id: str = "default"
    agency_name: str = "Notre Agence Immobilière"


class ChatResponse(BaseModel):
    reply: str
    session_id: str
    intent: str | None = None


@router.post("", response_model=ChatResponse)
async def chat(req: ChatRequest, db: AsyncSession = Depends(get_db)):
    # 1. Récupérer l'historique de la session (20 derniers messages)
    result = await db.execute(
        select(Message)
        .where(Message.session_id == req.session_id)
        .order_by(Message.created_at.asc())
        .limit(20)
    )
    history = result.scalars().all()

    messages = [{"role": m.role, "content": m.content} for m in history]
    messages.append({"role": "user", "content": req.message})

    # 2. Détecter l'intention (en parallèle pour ne pas ralentir)
    intent = await detect_intent(req.message)

    # 3. Construire le system prompt avec les annonces de l'agence
    system_prompt = build_system_prompt(
        agency_name=req.agency_name,
        listings=SAMPLE_LISTINGS,  # TODO: charger depuis DB selon agency_id
        agency_info="",
        calendly_url=settings.calendly_event_url,
    )

    # 4. Appel LLM
    reply = await chat_completion(messages=messages, system_prompt=system_prompt)

    # 5. Persister user message + réponse
    db.add(Message(session_id=req.session_id, role="user", content=req.message, agency_id=req.agency_id))
    db.add(Message(session_id=req.session_id, role="assistant", content=reply, agency_id=req.agency_id))

    # 6. Créer ou mettre à jour le lead
    lead_result = await db.execute(
        select(Lead).where(Lead.session_id == req.session_id)
    )
    lead = lead_result.scalar_one_or_none()
    if not lead:
        lead = Lead(session_id=req.session_id, agency_id=req.agency_id, intent=intent)
        db.add(lead)
    elif intent and intent != "question":
        lead.intent = intent

    await db.commit()
    return ChatResponse(reply=reply, session_id=req.session_id, intent=intent)
