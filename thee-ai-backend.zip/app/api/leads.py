from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.lead import Lead
from app.services.email import notify_agency_new_lead

router = APIRouter(prefix="/leads", tags=["leads"])


class LeadUpdate(BaseModel):
    session_id: str
    first_name: str | None = None
    last_name: str | None = None
    email: str | None = None
    phone: str | None = None
    budget: str | None = None
    location_pref: str | None = None
    property_type: str | None = None
    notes: str | None = None


@router.post("/update")
async def update_lead(data: LeadUpdate, db: AsyncSession = Depends(get_db)):
    """
    Met à jour les infos d'un lead identifié par session_id.
    Appelé automatiquement quand le chat collecte email / prénom.
    """
    result = await db.execute(select(Lead).where(Lead.session_id == data.session_id))
    lead = result.scalar_one_or_none()

    if not lead:
        lead = Lead(session_id=data.session_id)
        db.add(lead)

    for field, value in data.model_dump(exclude_none=True, exclude={"session_id"}).items():
        setattr(lead, field, value)

    await db.commit()

    # Notifier l'agence si on vient de capter un email
    if data.email:
        await notify_agency_new_lead(lead)

    return {"status": "ok", "lead_id": lead.id}


@router.get("")
async def list_leads(agency_id: str = "default", db: AsyncSession = Depends(get_db)):
    """Liste tous les leads d'une agence (pour dashboard simple)."""
    result = await db.execute(
        select(Lead)
        .where(Lead.agency_id == agency_id)
        .order_by(Lead.created_at.desc())
        .limit(100)
    )
    leads = result.scalars().all()
    return {"leads": [
        {
            "id": l.id,
            "name": f"{l.first_name or ''} {l.last_name or ''}".strip() or "Anonyme",
            "email": l.email,
            "phone": l.phone,
            "intent": l.intent,
            "budget": l.budget,
            "rdv": l.rdv_scheduled,
            "created_at": l.created_at.isoformat() if l.created_at else None,
        }
        for l in leads
    ]}
