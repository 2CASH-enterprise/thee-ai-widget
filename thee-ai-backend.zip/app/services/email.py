import httpx
from app.config import settings


async def notify_agency_new_lead(lead) -> None:
    """Envoie un email à l'agence quand un nouveau lead est qualifié."""
    if not settings.sendgrid_api_key:
        print(f"[EMAIL SKIPPED] Nouveau lead : {lead.email}")
        return

    body = f"""
    <h2>🏠 Nouveau lead qualifié</h2>
    <p><strong>Nom :</strong> {lead.first_name or ''} {lead.last_name or ''}</p>
    <p><strong>Email :</strong> {lead.email}</p>
    <p><strong>Téléphone :</strong> {lead.phone or 'Non renseigné'}</p>
    <p><strong>Projet :</strong> {lead.intent or 'Non précisé'}</p>
    <p><strong>Budget :</strong> {lead.budget or 'Non précisé'}</p>
    <p><strong>Secteur :</strong> {lead.location_pref or 'Non précisé'}</p>
    <p><strong>RDV pris :</strong> {'✅ Oui' if lead.rdv_scheduled else '❌ Non'}</p>
    """

    payload = {
        "personalizations": [{"to": [{"email": settings.from_email}]}],
        "from": {"email": settings.from_email},
        "subject": f"🏠 Nouveau lead : {lead.email}",
        "content": [{"type": "text/html", "value": body}],
    }

    async with httpx.AsyncClient() as client:
        await client.post(
            "https://api.sendgrid.com/v3/mail/send",
            json=payload,
            headers={"Authorization": f"Bearer {settings.sendgrid_api_key}"},
            timeout=10,
        )
